<?php
class OrderRepository {
	
	function persist(Order $order) {

	}

}
?>