<?php
class LoginService {

	function checkUser() {
		return true;
	}

}

?>