<form action="welcome.php">
	Name: <input type="text" id="username"/>
	Password: <input type="password" id="password"/>
	<input type="submit" value="Login"/>
</form>`