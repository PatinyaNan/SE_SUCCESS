<?php
class EmailSender {
	
	function send(Email $email) {
		
	}

}
?>