<?php
class Email {
	
}
?>