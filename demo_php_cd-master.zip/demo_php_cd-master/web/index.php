<?php
class Hello {

	function sayHi() {
		return "Hello World";
	}

}

echo "<input type='text'/>";

?>